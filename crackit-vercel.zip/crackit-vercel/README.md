# CrackIt — 压力面试模拟器

## 文件说明

```
crackit-vercel/
├── api/
│   └── chat.js          # Vercel Serverless Function（代理 GLM API，Key 放这里）
├── public/
│   └── index.html       # 前端（API Key 已移除，无需用户填写）
├── vercel.json          # Vercel 路由配置
└── package.json
```

---

## 10 分钟部署到 Vercel（免费）

### 第一步：上传到 GitHub
1. 在 GitHub 新建仓库（比如 `crackit`）
2. 把这个文件夹的内容全部上传

### 第二步：在 Vercel 导入
1. 打开 [vercel.com](https://vercel.com)，用 GitHub 登录
2. 点击 **Add New → Project**
3. 选择你刚创建的 GitHub 仓库，点击 **Import**
4. Framework Preset 选 **Other**，直接点 **Deploy**

### 第三步：设置环境变量（关键！）
1. 部署完成后，进入项目 → **Settings → Environment Variables**
2. 添加：
   - Name: `ZHIPU_API_KEY`
   - Value: 你的智谱 API Key（从 [open.bigmodel.cn](https://open.bigmodel.cn) 获取）
3. 点击 **Save**
4. 回到 **Deployments** → 点 **Redeploy**（让环境变量生效）

### 第四步：分享链接
Vercel 会给你一个 `https://crackit-xxx.vercel.app` 的链接，直接分享给朋友即可。
所有人都不需要填 API Key，Key 完全在服务器端，前端看不到。

---

## 功能说明

| 功能 | 说明 |
|------|------|
| 公司选择 | 8家主流互联网公司（chip 单选）|
| 岗位选择 | 下拉预设15+岗位 OR 自定义填写 |
| Demo 模式 | 3轮预置对话，不消耗 Token，适合分享预览 |
| 真实面试 | GLM-4-flash 驱动，搜索真实面经 + 结合简历 |
| 即时反馈 | **每轮**给出逻辑问题 + 语言表达 + 方法论 + 优化示范 + 评分 |
| 侧边栏评分 | 实时更新逻辑/表达分数 |

---

## 本地开发

```bash
# 安装 Vercel CLI
npm i -g vercel

# 在项目根目录
vercel dev
# 访问 http://localhost:3000
```

本地开发时，在项目根目录新建 `.env.local`：
```
ZHIPU_API_KEY=你的key
```
